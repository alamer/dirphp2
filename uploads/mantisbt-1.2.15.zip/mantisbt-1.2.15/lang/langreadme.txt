All files within this directory should use UTF-8 encoding to allow for Mantis
multilingual operation.

Translations are performed on translatewiki.net at:
http://translatewiki.net/wiki/Translating:Mantis

If you would like to help Translate Mantis to your native language, a good
place to start is the translatewiki introduction guide located at:
http://translatewiki.net/wiki/Translating:Intro
